import socket

sport = 5004
s =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)
#s.bind((socket.gethostname(),80))
s.bind(( '127.0.0.1' ,sport))
s.listen(1) #number of connection requests

while (1):
	print("Connection ready")
	(clientsocket,address) = s.accept()
	try:
		request = clientsocket.recv(1024) #assuming only the GET requests are being send to the system
		file_name = request.split()[1] #GET filename
		print("Requested file: {}".format(file_name))
		content = open(file_name.strip()).read() #using encode for sending bytes
		clientsocket.send('HTTP/1.1 200 OK\n\r'.encode())
		clientsocket.send(content.encode())
		clientsocket.close()
	except:
		clientsocket.send('HTTP/1.1 404 FIle not found\n\n'.encode())
		clientsocket.send('404 File not found'.encode())
		clientsocket.close()




