import socket
sport = 5004
s =  socket.socket(socket.AF_INET, socket.SOCK_STREAM)

#s.bind((socket.gethostname(),80))
s.connect(( '127.0.0.1' ,sport))
print("Connection established on IP: {}".format('127.0.0.1'))
filename = input()
while(filename != "End!!!"):
	s.send(("GET "+filename).encode())
	print("Requested file {}".format(filename))
	content = s.recv(1024)
	print(content)
	filename = input()
s.close()
